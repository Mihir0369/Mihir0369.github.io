Collision severity and risk factors in Canada: Power BI project (PBIP)

1. Copy this folder to C:\collision-risk (or any path).
2. If you use another path, open collision-risk.SemanticModel\definition\expressions.tmdl and change the ModelFolder value
   to the full path of the "model" folder inside this project.
3. Open collision-risk.pbip in Power BI Desktop (free). Turn on the Developer mode / PBIP preview feature if prompted, then click Refresh.
   The first refresh loads about 25 MB of CSV files, so give it a minute.

The CSV files in "model" were built from the Transport Canada National Collision Database, 2019 and 2020
(Open Government Licence - Canada): police-reported fatal and injury collisions. They are not insurance claims.
Unknown values are kept as an "Unknown or not reported" member in every dimension and are never treated as zero.

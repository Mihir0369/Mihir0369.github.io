Toronto 311 Power BI project (PBIP)

1. Copy this folder to C:\toronto-311 (or any path).
2. If you use another path, open toronto-311.SemanticModel\definition\expressions.tmdl and change the CsvPath value to the full path of requests_monthly_agg.csv.
3. Open toronto-311.pbip in Power BI Desktop (free). Enable the Developer mode / PBIP preview feature if prompted, then click Refresh.

requests_monthly_agg.csv is a monthly summary of City of Toronto 311 Service Requests (Open Data Toronto, Open Government Licence - Toronto), 2023 to 2025.

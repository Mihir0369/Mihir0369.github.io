Opioid and stimulant harms in Canada: Power BI project (PBIP)

1. Copy this folder to C:\opioid-harms (or any path).
2. If you use another path, open opioid-harms.SemanticModel\definition\expressions.tmdl and change the ModelFolder value
   to the full path of the "model" folder inside this project.
3. Open opioid-harms.pbip in Power BI Desktop (free). Turn on the Developer mode / PBIP preview feature if prompted, then click Refresh.

The CSV files in "model" were built from the Public Health Agency of Canada file "Opioid- and Stimulant-related Harms in Canada"
(Open Government Licence - Canada). They are aggregated counts and rates, not patient records.
Values marked Suppressed or Not available in the model are kept as such and are never treated as zero.

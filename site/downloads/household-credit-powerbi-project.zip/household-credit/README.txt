Household credit and interest rates: Power BI project (PBIP)

1. Copy this folder to C:\household-credit (or any path).
2. If you use another path, open household-credit.SemanticModel\definition\expressions.tmdl and change the ModelFolder value
   to the full path of the "model" folder inside this project.
3. Open household-credit.pbip in Power BI Desktop (free). Turn on the Developer mode / PBIP preview feature if prompted, then click Refresh.

The CSV files in "model" were built from the Bank of Canada Valet API and Statistics Canada tables 36-10-0639, 38-10-0238 and 11-10-0065
(Bank of Canada terms; Statistics Canada Open Licence). They are market-level data, not customer data.
